//����һ��ģ���ֻ��Դ���Ϸ��ħ����˾������Ϸ
//�淨�����������������ͼ�꼴�ɽ��������������������������ͬ��ͼ���ų�һ�л�һ�У�����ȥ��
//Ŀǰ�汾ʱ������

//�޸��������е�����3���Ըı��Ѷȣ���1��20�Կɡ�������8��̫���ˡ�
char LV=2;

//���������е�0�ĳ�1֮�󣬼�ʹ����������ȥ��Ҳ��������
char NOLIMIT=0;

//��1����������ͼ�����С�
//������ʱ��������ʲô�Ĵ����˻��棬��2������ˢ����ʾ��
//���������ҹ��ܼ����˳���

//���ߣ��ϻ�����Ӿ
//ͼƬ��Դ���ӡ�ħ��������.mrp����ȡ




#include <base.h>
#include <android.h>

#define LCDW 240
#define LCDH 320

#define APKPAGE 1

#include "echo.h"
#include "math.c"

char BOX[80];
char DEL[80];
char MAX;
char ADD;
void *TITLE;
void *BACK;
void *CHOSD;
char CHS=-1;
char CHSD=-1;
uint8 TIME[3];
int TIMER;
int COUNT=0;

int init(void)
{
setscrsize(240,240*SCRH/SCRW);
err(fread("title.bmp",&TITLE,70560));
err(fread("back.bmp",&BACK,1352));
err(fread("choosed.bmp",&CHOSD,1352));
MAX=LV+4;
if(MAX<2||MAX>45)err(-3);
sand(getuptime());
ADD=rand()%(45-MAX);
setall();
backdrawall();
drawall();
TIMER=timercreate();
timerstart(TIMER,100,0,"timer",1);
if(check(0,0,8,10))del(0,0,8,10,0);
return 0;
}

int event(int type, int p, int p2)
{
if(MS_UP==type)
 msclick(p,p2);
else if(KY_UP==type)
 {
switch(p)
  {
case _SRIGHT:
exitapp();
break;
case _1:
setall();
drawall();
if(check(0,0,8,10))del(0,0,8,10,0);
break;
case _2:
backdrawall();
drawall();
break;
  }
 }
return 0;
}

int pause(void)
{
timerstop(TIMER);
return 0;
}

int resume(void)
{
backdrawall();
drawall();
timerstart(TIMER,100,0,"timer",1);
return 0;
}
void freep(void **p)
{
if(*p!=NULL)
 {free(*p);*p=NULL;}
}
int exitapp(void)
{
freep(&TITLE);
freep(&BACK);
freep(&CHOSD);
if(TIMER!=0)
{timerstop(TIMER);timerdel(TIMER);TIMER=0;}
exit();
return 0;
}

void setall(void)
{
int i,t;
for(i=0;i<80;i++)
 {
sand(getuptime());
t=rand()%MAX+ADD;
BOX[i]=t;
DEL[i]=0;
 }
}
int fread(char *name,void **val,int len)
{
int p;
#ifdef APKPAGE
*val=readFileFromAssets(name,&len);
#else
p=open(name,1);
if(p==0)
 return -1;
*val=malloc(len);
if(val==NULL)
 {close(p);return -2;}
read(p,*val,len);
close(p);
#endif
return 0;
}

void drawall(void)
{
int i,t,x,y;
x=8;y=20;
for(i=0;i<80;i++)
 {
t=BOX[i]*28;
bmpshowflip(TITLE,x,y,28,28,28,BM_COPY,0,t,0);
x+=28;
if(x>=232)
{x=8;y+=28;}
 }
ref(0,0,240,320);
}

void err(int m)
{
switch(m)
 {
case -1:
echo("ͼƬ��ʧ��",m);
break;
case -2:
echo("�ڴ治�㣡",m);
break;
case -3:
echo("ѡ�ش���",m);
break;
 }
if(m<0)
 {sleep(2000);
 //exitapp();
 }
}

void backdrawall(void)
{
int x,y;
for(x=0;x<240;x+=26)
 {
for(y=0;y<320;y+=26)
  {
bmpshowflip(BACK,x,y,26,26,26,BM_COPY,0,0,0);
  }
 }
}

void msclick(int x,int y)
{
int t;
if(x<8||y<20) return;
x-=8;
y-=20;
EchoY=LCDH;
t=y/28*8+x/28;
if(t>=0&&t<80)
 chs(t);
}

void chs(int t)
{
int x,y;
if(t<0||t>=80)return;
y=t/8;
x=t-y*8;
x=x*28+9;
y=y*28+21;
bmpshowflip(CHOSD,x,y,26,26,26,BM_TRANS,0,0,0xffff);
ref(x,y,26,26);
if(CHS!=-1&&CHS!=t)
 {
if((t+1==CHS&&CHS%8!=0) || (t-1==CHS&&t%8!=0) || (t+8==CHS) || (t-8==CHS))
  {
CHSD=CHS;
CHS=t;
exchange();
  }
else
  {
showt(CHS);
CHS=t;
  }
 }
else
 {
CHS=t;
 }
}
void showt(int t)
{
int x,y;
if(t<0||t>=80)return;
y=t/8;
x=t-y*8;
x=x*28+8;
y=y*28+20;
bmpshowflip(TITLE,x,y,28,28,28,BM_COPY,0,BOX[t]*28,0);
ref(x,y,28,28);
}

void exchange(void)
{
int t,x,x2,x3,y,y2,y3,w,h,cnt;
t=BOX[CHS];
BOX[CHS]=BOX[CHSD];
BOX[CHSD]=t;
showt(CHS);
showt(CHSD);
y2=CHS/8;
x2=CHS-y2*8;
y3=CHSD/8;
x3=CHSD-y3*8;
x=min(x2,x3);
y=min(y2,y3);
w=max(x2,x3)+1;
h=max(y2,y3)+1;
if(w==7) {w++;}
else if(w<7){w+=2;}
if(h==9) {h++;}
else if(h<9) {h+=2;}
if(x==1) {x--;}
else if(x>1){x-=2;}
if(y==1) {y--;}
else if(y>1){y-=2;}
cnt=check(x,y,w,h);
if(cnt>0)
{
COUNT+=cnt;
del(x,y,w,h,0);
}
else if(NOLIMIT==0)
{
t=BOX[CHS];
BOX[CHS]=BOX[CHSD];
BOX[CHSD]=t;
showt(CHS);showt(CHSD);
}
CHS=-1;
CHSD=-1;
}

int check(int x0,int y0,int w,int h)
{
int x,y,c=0,t;
if(x0<0||x0>=8||y0<0||y0>=10||w<0||w>8||h<0||h>10)return;
w-=2;
for(x=x0;x<w;x++)
 {
for(y=y0;y<h;y++)
  {
t=y*8+x;
if((BOX[t]==BOX[t+1])&&(BOX[t]==BOX[t+2]))
{DEL[t]=1;DEL[t+1]=1;DEL[t+2]=1;c++;}
  }
 }
w+=2;h-=2;
for(y=y0;y<h;y++)
 {
for(x=x0;x<w;x++)
  {
t=y*8+x;
if((BOX[t]==BOX[t+8])&&(BOX[t]==BOX[t+16]))
{DEL[t]=1;DEL[t+8]=1;DEL[t+16]=1;c++;}
  }
 }
return c;
}

void del(int x0,int y0,int w,int h,char nodg)
{
int i,t,x,y,ma,mb,mc,a=7,b=0,c=0,mv=0;
if(x0<0||x0>=8||y0<0||y0>=10||w<0||w>8||h<0||h>10)return;
for(x=x0;x<w;x++)
{for(y=y0;y<h;y++){i=y*8+x;if(DEL[i]==1){ma=x*28+9;mb=y*28+21;bmpshowflip(BACK,ma,mb,26,26,26,BM_COPY,0,0,0);ref(ma,mb,26,26);}}}
for(x=x0;x<w;x++)
 {for(y=y0;y<h;y++)
 {
i=y*8+x;
if(DEL[i]==1)
  {
move(i);mv=1;
ma=x;mb=x;mc=y;
if(ma==1) ma--;
else if(ma>1)ma-=2;
if(mb==6) mb++;
else if(mb<6)mb+=2;
if(mc==8) mc++;
else if(mc<8)mc+=2;
a=min(a,ma);b=max(b,mb);c=max(c,mc);
DEL[i]=0;
  }
 }}
b++;c++;
if(mv==1&&nodg==0)while(check(a,0,b,c))del(a,0,b,c,1);
}

void move(int t)
{
int i,x,y;
if(t<0||t>=80)return;
for(i=t;i>7;i-=8)
 {
BOX[i]=BOX[i-8];
y=i/8;x=i-y*8;
y=y*28+20;
x=x*28+8;
bmpshowflip(TITLE,x,y,28,28,28,BM_COPY,0,BOX[i]*28,0);
 }
sand(getuptime());
BOX[i]=rand()%MAX+ADD;
y=i/8;x=i-y*8;
y=y*28+20;x=x*28+8;
bmpshowflip(TITLE,x,y,28,28,28,BM_COPY,0,BOX[i]*28,0);
y=t/8;x=t-y*8;
x=x*28+8;y++;
ref(x,20,28,y*28);
}

void timer(int data)
{
int x,y;
TIME[2]++;char a[50];
if(TIME[2]>=10)
{TIME[2]=0;TIME[1]++;}
if(TIME[1]>=60)
  {
  TIME[1]=0;TIME[0]++;
  }
sprintf(a,"%d:%d.%d �÷�:%d",TIME[0],TIME[1],TIME[2],COUNT);
for(x=0;x<156;x+=52)
  {
  for ( y=0; y<18; y+=9)
    {
  bmpshowflip(BACK,x,y,52,52,9,BM_COPY,0,0,0);
    }
  }
dtext(a,0,0,255,255,255,0,1);
ref(0,0,156,18);
}
