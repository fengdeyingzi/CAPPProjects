int FontW,FontH,EchoH,EchoY;
textwh("��",0,1,&FontW,&FontH);
EchoH=LCDH-FontH*3-8;
EchoY=LCDH;
char EchoT[256];
void echo(char *a,int b)
{
if(EchoY>=LCDH)
 {
drect(0,EchoH,LCDW,LCDH-EchoH,0,100,0);
EchoY=EchoH+2;
ref(0,EchoH,LCDW,LCDH-EchoH);
 }
sprintf(EchoT,"%s%d",a,b);
dtext(EchoT,0,EchoY,255,255,255,0,1);
ref(0,EchoY,LCDW,FontH);
EchoY+=FontH+2;
}
