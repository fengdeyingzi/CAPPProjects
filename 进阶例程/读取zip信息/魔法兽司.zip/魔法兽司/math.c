int abs(int a,int b)
{
b-=a;
return b<0 ? -b : b;
}
int max(int a,int b)
{return a<b ? b : a;}
int min(int a,int b)
{return a<b ? a : b;}
